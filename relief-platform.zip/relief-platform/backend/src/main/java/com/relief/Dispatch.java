package com.relief;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Getter @Setter @NoArgsConstructor
public class Dispatch {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private Long areaId;
    private Long warehouseId;
    @Enumerated(EnumType.STRING) private ResourceType type;
    private int quantity;
    private double distanceKm;
    @Enumerated(EnumType.STRING) private DispatchStatus status;
    private LocalDateTime createdAt = LocalDateTime.now();
}
