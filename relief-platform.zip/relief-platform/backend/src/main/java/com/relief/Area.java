package com.relief;

import jakarta.persistence.*;
import lombok.*;

@Entity @Getter @Setter @NoArgsConstructor
public class Area {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private String name;
    private double lat;
    private double lng;
    private int severity;   // 1-5
    private int urgency;    // 1-5
    private int population;

    /** priority = severity x urgency x population (in thousands) */
    public double getPriority() { return severity * urgency * (population / 1000.0); }
}
