package com.relief;

import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ApiController {

    record ReqBody(ResourceType type, int required) {}
    record StockBody(ResourceType type, int quantity, int threshold) {}

    private final ReliefService svc;
    private final AreaRepo areas;
    private final WarehouseRepo warehouses;

    @GetMapping("/me")
    Map<String, String> me(Authentication a) {
        String role = a.getAuthorities().iterator().next().getAuthority().replace("ROLE_", "");
        return Map.of("username", a.getName(), "role", role);
    }

    // ----- Areas (relief operator, admin) -----
    @GetMapping("/areas") List<Area> areas() { return areas.findAll(); }

    @PostMapping("/areas") @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    Area addArea(@RequestBody Area a) { a.setId(null); return areas.save(a); }

    @DeleteMapping("/areas/{id}") @PreAuthorize("hasRole('ADMIN')")
    void deleteArea(@PathVariable Long id) { svc.deleteArea(id); }

    @PostMapping("/areas/{id}/requirements") @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    void requirement(@PathVariable Long id, @RequestBody ReqBody b) { svc.setRequirement(id, b.type(), b.required()); }

    // ----- Warehouses (warehouse manager, admin) -----
    @GetMapping("/warehouses") List<ReliefService.WarehouseView> warehouses() { return svc.warehouseViews(); }

    @PostMapping("/warehouses") @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    Warehouse addWarehouse(@RequestBody Warehouse w) { w.setId(null); return warehouses.save(w); }

    @PostMapping("/warehouses/{id}/stock") @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    void addStock(@PathVariable Long id, @RequestBody StockBody b) { svc.addStock(id, b.type(), b.quantity(), b.threshold()); }

    // ----- Dashboard -----
    @GetMapping("/dashboard") List<ReliefService.GapRow> dashboard() { return svc.gaps(); }

    @GetMapping("/dashboard/export")
    ResponseEntity<String> export() {
        return ResponseEntity.ok()
            .header(HttpHeaders.CONTENT_TYPE, "text/csv")
            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=relief-gaps.csv")
            .body(svc.csv());
    }

    // ----- Allocation and dispatch -----
    @PostMapping("/allocation/suggest") @PreAuthorize("hasRole('ADMIN')")
    List<ReliefService.DispatchView> suggest() { svc.suggest(); return svc.dispatchViews(); }

    @GetMapping("/dispatches") List<ReliefService.DispatchView> dispatches() { return svc.dispatchViews(); }

    @PostMapping("/dispatches/{id}/approve") @PreAuthorize("hasRole('ADMIN')")
    void approve(@PathVariable Long id) { svc.move(id, DispatchStatus.SUGGESTED, DispatchStatus.APPROVED); }

    @PostMapping("/dispatches/{id}/dispatch") @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    void dispatch(@PathVariable Long id) { svc.move(id, DispatchStatus.APPROVED, DispatchStatus.DISPATCHED); }

    @PostMapping("/dispatches/{id}/deliver") @PreAuthorize("hasAnyRole('ADMIN','OPERATOR')")
    void deliver(@PathVariable Long id) { svc.move(id, DispatchStatus.DISPATCHED, DispatchStatus.DELIVERED); }
}
