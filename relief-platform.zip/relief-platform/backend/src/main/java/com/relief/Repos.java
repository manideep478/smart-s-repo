package com.relief;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

interface UserRepo extends JpaRepository<AppUser, Long> { Optional<AppUser> findByUsername(String username); }
interface AreaRepo extends JpaRepository<Area, Long> {}
interface WarehouseRepo extends JpaRepository<Warehouse, Long> {}
interface RequirementRepo extends JpaRepository<Requirement, Long> {
    Optional<Requirement> findByAreaIdAndType(Long areaId, ResourceType type);
    void deleteByAreaId(Long areaId);
}
interface StockRepo extends JpaRepository<Stock, Long> {
    List<Stock> findByWarehouseId(Long warehouseId);
    Optional<Stock> findByWarehouseIdAndType(Long warehouseId, ResourceType type);
}
interface DispatchRepo extends JpaRepository<Dispatch, Long> {
    void deleteByStatus(DispatchStatus status);
    void deleteByAreaId(Long areaId);
}
