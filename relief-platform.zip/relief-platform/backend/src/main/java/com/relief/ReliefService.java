package com.relief;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReliefService {

    public record GapRow(Long areaId, String area, ResourceType type, int required, int committed,
                         int shortfall, String status, double priority) {}
    public record DispatchView(Long id, Long areaId, String area, Long warehouseId, String warehouse,
                               ResourceType type, int quantity, double distanceKm, DispatchStatus status) {}
    public record StockView(Long id, ResourceType type, int quantity, int threshold, boolean low) {}
    public record WarehouseView(Long id, String name, double lat, double lng, List<StockView> stock) {}

    private final AreaRepo areas;
    private final WarehouseRepo warehouses;
    private final RequirementRepo reqs;
    private final StockRepo stocks;
    private final DispatchRepo dispatches;

    // ---------- Resource gap analysis ----------
    // committed = quantity in APPROVED / DISPATCHED / DELIVERED dispatches (SUGGESTED does not count)
    public List<GapRow> gaps() {
        List<Dispatch> ds = dispatches.findAll();
        Map<Long, Area> am = areas.findAll().stream().collect(Collectors.toMap(Area::getId, Function.identity()));
        List<GapRow> out = new ArrayList<>();
        for (Requirement r : reqs.findAll()) {
            Area a = am.get(r.getAreaId());
            if (a == null) continue;
            int committed = ds.stream()
                .filter(d -> d.getAreaId().equals(r.getAreaId()) && d.getType() == r.getType()
                          && d.getStatus() != DispatchStatus.SUGGESTED)
                .mapToInt(Dispatch::getQuantity).sum();
            int shortfall = Math.max(0, r.getRequired() - committed);
            double ratio = r.getRequired() == 0 ? 1 : (double) committed / r.getRequired();
            String status = ratio >= 1 ? "FULFILLED" : ratio >= 0.5 ? "PARTIAL" : "CRITICAL";
            out.add(new GapRow(a.getId(), a.getName(), r.getType(), r.getRequired(), committed,
                               shortfall, status, a.getPriority()));
        }
        out.sort((x, y) -> Double.compare(y.priority(), x.priority()));
        return out;
    }

    // ---------- Smart allocation engine ----------
    // 1. Areas are served in descending priority (severity x urgency x population).
    // 2. For each shortfall, warehouses are tried nearest-first (haversine distance).
    // 3. Stock is split across warehouses when one cannot cover the whole shortfall.
    @Transactional
    public void suggest() {
        dispatches.deleteByStatus(DispatchStatus.SUGGESTED);
        Map<Long, Area> am = areas.findAll().stream().collect(Collectors.toMap(Area::getId, Function.identity()));
        List<Warehouse> whs = warehouses.findAll();
        Map<String, Integer> free = new HashMap<>();
        for (Stock s : stocks.findAll()) free.put(s.getWarehouseId() + ":" + s.getType(), s.getQuantity());

        List<Dispatch> out = new ArrayList<>();
        for (GapRow g : gaps()) {                       // already sorted by priority
            int need = g.shortfall();
            if (need <= 0) continue;
            Area a = am.get(g.areaId());
            List<Warehouse> nearest = whs.stream()
                .sorted(Comparator.comparingDouble(w -> km(a.getLat(), a.getLng(), w.getLat(), w.getLng())))
                .toList();
            for (Warehouse w : nearest) {
                if (need == 0) break;
                String key = w.getId() + ":" + g.type();
                int avail = free.getOrDefault(key, 0);
                if (avail <= 0) continue;
                int q = Math.min(avail, need);
                Dispatch d = new Dispatch();
                d.setAreaId(a.getId());
                d.setWarehouseId(w.getId());
                d.setType(g.type());
                d.setQuantity(q);
                d.setDistanceKm(Math.round(km(a.getLat(), a.getLng(), w.getLat(), w.getLng()) * 10) / 10.0);
                d.setStatus(DispatchStatus.SUGGESTED);
                out.add(d);
                free.put(key, avail - q);
                need -= q;
            }
        }
        dispatches.saveAll(out);
    }

    static double km(double lat1, double lon1, double lat2, double lon2) {
        double dLat = Math.toRadians(lat2 - lat1), dLon = Math.toRadians(lon2 - lon1);
        double x = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                 + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                 * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return 2 * 6371 * Math.asin(Math.sqrt(x));
    }

    // ---------- Dispatch workflow: SUGGESTED -> APPROVED -> DISPATCHED -> DELIVERED ----------
    @Transactional
    public void move(Long id, DispatchStatus from, DispatchStatus to) {
        Dispatch d = dispatches.findById(id)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Dispatch not found"));
        if (d.getStatus() != from)
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Dispatch is already " + d.getStatus());
        if (to == DispatchStatus.APPROVED) {            // stock is deducted on approval
            Stock s = stocks.findByWarehouseIdAndType(d.getWarehouseId(), d.getType())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.CONFLICT, "No stock record"));
            if (s.getQuantity() < d.getQuantity())
                throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Not enough stock left. Generate suggestions again.");
            s.setQuantity(s.getQuantity() - d.getQuantity());
        }
        d.setStatus(to);
    }

    public List<DispatchView> dispatchViews() {
        Map<Long, Area> am = areas.findAll().stream().collect(Collectors.toMap(Area::getId, Function.identity()));
        Map<Long, Warehouse> wm = warehouses.findAll().stream().collect(Collectors.toMap(Warehouse::getId, Function.identity()));
        return dispatches.findAll().stream()
            .sorted(Comparator.comparing(Dispatch::getId).reversed())
            .filter(d -> am.containsKey(d.getAreaId()) && wm.containsKey(d.getWarehouseId()))
            .map(d -> new DispatchView(d.getId(), d.getAreaId(), am.get(d.getAreaId()).getName(),
                d.getWarehouseId(), wm.get(d.getWarehouseId()).getName(), d.getType(),
                d.getQuantity(), d.getDistanceKm(), d.getStatus()))
            .toList();
    }

    // ---------- Warehouses and stock ----------
    public List<WarehouseView> warehouseViews() {
        return warehouses.findAll().stream().map(w -> new WarehouseView(w.getId(), w.getName(), w.getLat(), w.getLng(),
            stocks.findByWarehouseId(w.getId()).stream()
                .map(s -> new StockView(s.getId(), s.getType(), s.getQuantity(), s.getThreshold(),
                                        s.getQuantity() <= s.getThreshold()))
                .toList())).toList();
    }

    @Transactional
    public void addStock(Long warehouseId, ResourceType type, int qty, int threshold) {
        Stock s = stocks.findByWarehouseIdAndType(warehouseId, type).orElseGet(() -> {
            Stock n = new Stock(); n.setWarehouseId(warehouseId); n.setType(type); return n; });
        s.setQuantity(s.getQuantity() + qty);
        if (threshold > 0) s.setThreshold(threshold);
        stocks.save(s);
    }

    // ---------- Areas and requirements ----------
    @Transactional
    public void setRequirement(Long areaId, ResourceType type, int required) {
        Requirement r = reqs.findByAreaIdAndType(areaId, type).orElseGet(() -> {
            Requirement n = new Requirement(); n.setAreaId(areaId); n.setType(type); return n; });
        r.setRequired(required);
        reqs.save(r);
    }

    @Transactional
    public void deleteArea(Long id) {
        reqs.deleteByAreaId(id);
        dispatches.deleteByAreaId(id);
        areas.deleteById(id);
    }

    public String csv() {
        StringBuilder sb = new StringBuilder("Area,Resource,Required,Committed,Shortfall,Status,Priority\n");
        for (GapRow g : gaps())
            sb.append('"').append(g.area()).append("\",").append(g.type()).append(',').append(g.required()).append(',')
              .append(g.committed()).append(',').append(g.shortfall()).append(',').append(g.status()).append(',')
              .append(String.format("%.1f", g.priority())).append('\n');
        return sb.toString();
    }
}
