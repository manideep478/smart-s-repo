package com.relief;

public enum ResourceType { FOOD, WATER, MEDICINE, SHELTER }
