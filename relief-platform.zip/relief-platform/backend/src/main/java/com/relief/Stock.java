package com.relief;

import jakarta.persistence.*;
import lombok.*;

@Entity @Getter @Setter @NoArgsConstructor
public class Stock {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private Long warehouseId;
    @Enumerated(EnumType.STRING) private ResourceType type;
    private int quantity;
    private int threshold; // low-stock alert level
}
