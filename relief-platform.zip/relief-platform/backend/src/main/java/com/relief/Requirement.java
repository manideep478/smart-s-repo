package com.relief;

import jakarta.persistence.*;
import lombok.*;

@Entity @Getter @Setter @NoArgsConstructor
public class Requirement {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private Long areaId;
    @Enumerated(EnumType.STRING) private ResourceType type;
    private int required;
}
