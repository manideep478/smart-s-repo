package com.relief;

import jakarta.persistence.*;
import lombok.*;

@Entity @Getter @Setter @NoArgsConstructor
public class AppUser {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(unique = true) private String username;
    private String password;
    private String role; // ADMIN, OPERATOR, WAREHOUSE
}
