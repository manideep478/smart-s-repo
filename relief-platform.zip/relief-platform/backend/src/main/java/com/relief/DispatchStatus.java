package com.relief;

public enum DispatchStatus { SUGGESTED, APPROVED, DISPATCHED, DELIVERED }
