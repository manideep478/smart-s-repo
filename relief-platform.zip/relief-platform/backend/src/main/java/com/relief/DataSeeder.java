package com.relief;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import static com.relief.ResourceType.*;

@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {
    private final UserRepo users;
    private final AreaRepo areas;
    private final WarehouseRepo warehouses;
    private final ReliefService svc;
    private final PasswordEncoder enc;

    @Override
    public void run(String... args) {
        if (users.count() > 0) return;
        user("admin", "admin123", "ADMIN");
        user("operator", "op123", "OPERATOR");
        user("warehouse", "wh123", "WAREHOUSE");

        Area srikakulam = area("Srikakulam coast", 18.2949, 83.8938, 5, 5, 42000);
        Area puri = area("Puri", 19.8135, 85.8312, 4, 4, 60000);
        Area nellore = area("Nellore", 14.4426, 79.9865, 3, 4, 35000);
        Area kakinada = area("Kakinada", 16.9891, 82.2475, 4, 3, 50000);
        for (Area a : new Area[]{srikakulam, puri, nellore, kakinada}) {
            svc.setRequirement(a.getId(), FOOD, a.getPopulation() / 10);
            svc.setRequirement(a.getId(), WATER, a.getPopulation() / 5);
        }
        svc.setRequirement(srikakulam.getId(), MEDICINE, 800);
        svc.setRequirement(puri.getId(), SHELTER, 600);

        Warehouse vizag = warehouse("Visakhapatnam depot", 17.6868, 83.2185);
        Warehouse vja = warehouse("Vijayawada depot", 16.5062, 80.6480);
        Warehouse bbsr = warehouse("Bhubaneswar depot", 20.2961, 85.8245);
        svc.addStock(vizag.getId(), FOOD, 5000, 800);
        svc.addStock(vizag.getId(), WATER, 9000, 1500);
        svc.addStock(vizag.getId(), MEDICINE, 500, 100);
        svc.addStock(vja.getId(), FOOD, 3000, 500);
        svc.addStock(vja.getId(), WATER, 6000, 1000);
        svc.addStock(bbsr.getId(), FOOD, 2500, 500);
        svc.addStock(bbsr.getId(), SHELTER, 400, 50);
        svc.addStock(bbsr.getId(), MEDICINE, 600, 100);
    }

    private void user(String name, String pass, String role) {
        AppUser u = new AppUser(); u.setUsername(name); u.setPassword(enc.encode(pass)); u.setRole(role); users.save(u);
    }
    private Area area(String name, double lat, double lng, int sev, int urg, int pop) {
        Area a = new Area(); a.setName(name); a.setLat(lat); a.setLng(lng);
        a.setSeverity(sev); a.setUrgency(urg); a.setPopulation(pop); return areas.save(a);
    }
    private Warehouse warehouse(String name, double lat, double lng) {
        Warehouse w = new Warehouse(); w.setName(name); w.setLat(lat); w.setLng(lng); return warehouses.save(w);
    }
}
