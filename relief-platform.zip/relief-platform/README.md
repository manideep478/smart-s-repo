# Disaster Relief Resource Coordination Platform

Spring Boot 3 + JPA (PostgreSQL or MySQL) backend, React + Vite + Leaflet frontend.

## Run
1. Create an empty database named `relief` and edit `backend/src/main/resources/application.properties`
   (PostgreSQL by default; MySQL lines are included as comments, swap the driver in `pom.xml` too).
2. Backend (Java 17, Maven):  `cd backend && mvn spring-boot:run`   -> http://localhost:8080
3. Frontend (Node 18+):       `cd frontend && npm install && npm run dev`   -> http://localhost:5173

Sample data and three demo users are created on first start:
admin / admin123, operator / op123, warehouse / wh123.

## Roles
- OPERATOR: report areas, set required quantities, mark dispatches delivered
- WAREHOUSE: register warehouses, add stock, mark dispatches dispatched
- ADMIN: everything, plus generate allocation, approve dispatches, delete areas

## Allocation engine (ReliefService.suggest)
Areas are served in descending priority = severity x urgency x population/1000.
For each shortfall, warehouses are tried nearest-first (haversine) and stock is split across
warehouses when needed. Suggestions are regenerated on each run; stock is deducted on approval.
