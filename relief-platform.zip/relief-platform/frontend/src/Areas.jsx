import { useState } from 'react';
import { api, useApi } from './api';

const TYPES = ['FOOD', 'WATER', 'MEDICINE', 'SHELTER'];

export default function Areas({ role }) {
  const [areas, load, error] = useApi('/areas');
  const [msg, setMsg] = useState('');
  const canEdit = role === 'ADMIN' || role === 'OPERATOR';

  async function run(fn, e) {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    try { await fn(f); e.target.reset(); setMsg(''); load(); } catch (x) { setMsg(x.message); }
  }

  const addArea = (e) => run((f) => api('/areas', 'POST', {
    name: f.name, lat: +f.lat, lng: +f.lng, severity: +f.severity, urgency: +f.urgency, population: +f.population,
  }), e);
  const addReq = (e) => run((f) => api(`/areas/${f.areaId}/requirements`, 'POST', { type: f.type, required: +f.required }), e);

  async function remove(id) {
    if (!confirm('Delete this area and its requirements and dispatches?')) return;
    try { await api('/areas/' + id, 'DELETE'); load(); } catch (x) { setMsg(x.message); }
  }

  if (error) return <p className="error">{error}</p>;
  if (!areas) return <p>Loading…</p>;

  return (
    <section>
      <h2>Affected areas</h2>
      {msg && <p className="error">{msg}</p>}
      {canEdit && (
        <div className="forms">
          <form className="card" onSubmit={addArea}>
            <h3>Report an affected area</h3>
            <input name="name" placeholder="Area name" required />
            <input name="lat" type="number" step="any" placeholder="Latitude" required />
            <input name="lng" type="number" step="any" placeholder="Longitude" required />
            <input name="population" type="number" min="1" placeholder="Population affected" required />
            <label>Severity (1-5)<input name="severity" type="number" min="1" max="5" defaultValue="3" required /></label>
            <label>Urgency (1-5)<input name="urgency" type="number" min="1" max="5" defaultValue="3" required /></label>
            <button>Add area</button>
          </form>
          <form className="card" onSubmit={addReq}>
            <h3>Set required quantity</h3>
            <select name="areaId" required>
              {areas.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
            <select name="type">{TYPES.map((t) => <option key={t}>{t}</option>)}</select>
            <input name="required" type="number" min="0" placeholder="Units required" required />
            <button>Save requirement</button>
          </form>
        </div>
      )}
      <table>
        <thead><tr><th>Area</th><th>Population</th><th>Severity</th><th>Urgency</th><th>Priority score</th><th /></tr></thead>
        <tbody>
          {[...areas].sort((a, b) => b.priority - a.priority).map((a) => (
            <tr key={a.id}>
              <td>{a.name}</td><td>{a.population.toLocaleString()}</td><td>{a.severity}</td><td>{a.urgency}</td>
              <td>{a.priority.toFixed(0)}</td>
              <td>{role === 'ADMIN' && <button className="link" onClick={() => remove(a.id)}>Delete</button>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
