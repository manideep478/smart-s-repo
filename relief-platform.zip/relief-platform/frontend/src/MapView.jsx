import { MapContainer, TileLayer, CircleMarker, Polyline, Tooltip } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { useApi } from './api';

const COLOR = { CRITICAL: '#b3261e', PARTIAL: '#b26a00', FULFILLED: '#1b6e3c', NONE: '#6b7280' };
const RANK = { CRITICAL: 0, PARTIAL: 1, FULFILLED: 2 };

export default function MapView() {
  const [areas] = useApi('/areas');
  const [whs] = useApi('/warehouses');
  const [gaps] = useApi('/dashboard');
  const [ds] = useApi('/dispatches');
  if (!areas || !whs || !gaps || !ds) return <p>Loading…</p>;

  const worst = (areaId) => {
    const s = gaps.filter((g) => g.areaId === areaId).map((g) => g.status);
    return s.length ? s.sort((a, b) => RANK[a] - RANK[b])[0] : 'NONE';
  };
  const areaPos = Object.fromEntries(areas.map((a) => [a.id, [a.lat, a.lng]]));
  const whPos = Object.fromEntries(whs.map((w) => [w.id, [w.lat, w.lng]]));

  return (
    <section>
      <h2>Map</h2>
      <p className="hint">Circles are affected areas (colour = worst gap status). Blue dots are warehouses. Dashed lines are suggested routes, solid lines are approved or in transit.</p>
      <MapContainer center={[17.5, 82]} zoom={6} className="map">
        <TileLayer attribution="&copy; OpenStreetMap contributors" url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {ds.filter((d) => d.status !== 'DELIVERED').map((d) => (
          <Polyline key={d.id} positions={[whPos[d.warehouseId], areaPos[d.areaId]]}
            pathOptions={{ color: '#1d4ed8', weight: 2, dashArray: d.status === 'SUGGESTED' ? '6 6' : undefined }} />
        ))}
        {areas.map((a) => (
          <CircleMarker key={'a' + a.id} center={[a.lat, a.lng]} radius={7 + a.severity * 2}
            pathOptions={{ color: COLOR[worst(a.id)], fillOpacity: 0.55 }}>
            <Tooltip>{a.name}: severity {a.severity}, urgency {a.urgency}</Tooltip>
          </CircleMarker>
        ))}
        {whs.map((w) => (
          <CircleMarker key={'w' + w.id} center={[w.lat, w.lng]} radius={7}
            pathOptions={{ color: '#1d4ed8', fillColor: '#1d4ed8', fillOpacity: 1 }}>
            <Tooltip>{w.name}</Tooltip>
          </CircleMarker>
        ))}
      </MapContainer>
    </section>
  );
}
