import { useState, useEffect, useCallback } from 'react';

let auth = sessionStorage.getItem('auth') || '';
export const setAuth = (u, p) => { auth = 'Basic ' + btoa(u + ':' + p); sessionStorage.setItem('auth', auth); };
export const clearAuth = () => { auth = ''; sessionStorage.removeItem('auth'); };
export const hasAuth = () => !!auth;

export async function api(path, method = 'GET', body) {
  const r = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: auth },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!r.ok) {
    let msg = r.statusText;
    try { msg = (await r.json()).message || msg; } catch { /* no body */ }
    const e = new Error(msg); e.status = r.status; throw e;
  }
  if ((r.headers.get('content-type') || '').includes('csv')) return r.text();
  const t = await r.text();
  return t ? JSON.parse(t) : null;
}

export function useApi(path) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const load = useCallback(
    () => api(path).then((d) => { setData(d); setError(''); }).catch((e) => setError(e.message)),
    [path]
  );
  useEffect(() => { load(); }, [load]);
  return [data, load, error];
}
