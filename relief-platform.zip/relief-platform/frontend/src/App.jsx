import { useState, useEffect } from 'react';
import { api, setAuth, clearAuth, hasAuth } from './api';
import Dashboard from './Dashboard';
import Areas from './Areas';
import Warehouses from './Warehouses';
import Dispatches from './Dispatches';
import MapView from './MapView';

const TABS = [
  ['dashboard', 'Resource gaps'],
  ['areas', 'Affected areas'],
  ['warehouses', 'Warehouses'],
  ['dispatches', 'Dispatches'],
  ['map', 'Map'],
];

export default function App() {
  const [me, setMe] = useState(null);
  const [tab, setTab] = useState('dashboard');
  const [err, setErr] = useState('');

  useEffect(() => {
    if (hasAuth()) api('/me').then(setMe).catch(() => clearAuth());
  }, []);

  async function login(e) {
    e.preventDefault();
    const f = new FormData(e.target);
    setAuth(f.get('u'), f.get('p'));
    try { setMe(await api('/me')); setErr(''); }
    catch { clearAuth(); setErr('Wrong username or password.'); }
  }

  if (!me) {
    return (
      <form className="login card" onSubmit={login}>
        <h1>Relief Coordination</h1>
        <label>Username<input name="u" required autoFocus /></label>
        <label>Password<input name="p" type="password" required /></label>
        {err && <p className="error">{err}</p>}
        <button>Sign in</button>
        <p className="hint">Demo: admin / admin123, operator / op123, warehouse / wh123</p>
      </form>
    );
  }

  const role = me.role;
  return (
    <>
      <header>
        <strong>Relief Coordination</strong>
        <nav>
          {TABS.map(([k, label]) => (
            <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{label}</button>
          ))}
        </nav>
        <span>{me.username} ({role.toLowerCase()})
          <button className="link" onClick={() => { clearAuth(); setMe(null); }}>Sign out</button>
        </span>
      </header>
      <main>
        {tab === 'dashboard' && <Dashboard />}
        {tab === 'areas' && <Areas role={role} />}
        {tab === 'warehouses' && <Warehouses role={role} />}
        {tab === 'dispatches' && <Dispatches role={role} />}
        {tab === 'map' && <MapView />}
      </main>
    </>
  );
}
