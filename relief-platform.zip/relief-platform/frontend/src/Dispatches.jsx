import { useState } from 'react';
import { api, useApi } from './api';

const STEPS = ['SUGGESTED', 'APPROVED', 'DISPATCHED', 'DELIVERED'];

export default function Dispatches({ role }) {
  const [list, load, error] = useApi('/dispatches');
  const [msg, setMsg] = useState('');

  async function act(call) {
    try { await call(); setMsg(''); } catch (x) { setMsg(x.message); }
    load();
  }
  const step = (id, action) => act(() => api(`/dispatches/${id}/${action}`, 'POST'));

  function button(d) {
    if (d.status === 'SUGGESTED' && role === 'ADMIN') return <button onClick={() => step(d.id, 'approve')}>Approve</button>;
    if (d.status === 'APPROVED' && (role === 'ADMIN' || role === 'WAREHOUSE'))
      return <button onClick={() => step(d.id, 'dispatch')}>Mark dispatched</button>;
    if (d.status === 'DISPATCHED' && (role === 'ADMIN' || role === 'OPERATOR'))
      return <button onClick={() => step(d.id, 'deliver')}>Mark delivered</button>;
    return null;
  }

  if (error) return <p className="error">{error}</p>;
  if (!list) return <p>Loading…</p>;

  return (
    <section>
      <div className="row">
        <h2>Dispatches</h2>
        {role === 'ADMIN' && (
          <button onClick={() => act(() => api('/allocation/suggest', 'POST'))}>Generate allocation</button>
        )}
      </div>
      <p className="hint">Flow: {STEPS.join(' → ').toLowerCase()}. Stock is deducted when a dispatch is approved.</p>
      {msg && <p className="error">{msg}</p>}
      {list.length === 0 && <p>No dispatches yet. An admin can generate an allocation from current gaps and stock.</p>}
      <table>
        <thead><tr><th>Area</th><th>From warehouse</th><th>Resource</th><th>Quantity</th><th>Distance</th><th>Status</th><th /></tr></thead>
        <tbody>
          {list.map((d) => (
            <tr key={d.id}>
              <td>{d.area}</td><td>{d.warehouse}</td><td>{d.type}</td><td>{d.quantity}</td>
              <td>{d.distanceKm} km</td>
              <td><span className={'badge s-' + d.status}>{d.status.toLowerCase()}</span></td>
              <td>{button(d)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
