import { api, useApi } from './api';

const pct = (r) => (r.required ? Math.min(100, Math.round((100 * r.committed) / r.required)) : 100);

export default function Dashboard() {
  const [rows, , error] = useApi('/dashboard');

  async function exportCsv() {
    const text = await api('/dashboard/export');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'text/csv' }));
    a.download = 'relief-gaps.csv';
    a.click();
  }

  if (error) return <p className="error">{error}</p>;
  if (!rows) return <p>Loading…</p>;
  const count = (s) => rows.filter((r) => r.status === s).length;

  return (
    <section>
      <div className="row">
        <h2>Required vs committed, by area</h2>
        <button onClick={exportCsv}>Export CSV</button>
      </div>
      <p className="summary">
        <span className="badge CRITICAL">{count('CRITICAL')} critical</span>
        <span className="badge PARTIAL">{count('PARTIAL')} partial</span>
        <span className="badge FULFILLED">{count('FULFILLED')} fulfilled</span>
      </p>
      {rows.length === 0 && <p>No requirements yet. Add them under Affected areas.</p>}
      <table>
        <thead><tr>
          <th>Area</th><th>Resource</th><th>Required</th><th>Committed</th><th>Shortfall</th><th>Coverage</th><th>Status</th>
        </tr></thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              <td>{r.area}</td><td>{r.type}</td><td>{r.required}</td><td>{r.committed}</td><td>{r.shortfall}</td>
              <td><div className="bar"><div className={r.status} style={{ width: pct(r) + '%' }} /></div></td>
              <td><span className={'badge ' + r.status}>{r.status.toLowerCase()}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
