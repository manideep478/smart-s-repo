import { useState } from 'react';
import { api, useApi } from './api';

const TYPES = ['FOOD', 'WATER', 'MEDICINE', 'SHELTER'];

export default function Warehouses({ role }) {
  const [list, load, error] = useApi('/warehouses');
  const [msg, setMsg] = useState('');
  const canEdit = role === 'ADMIN' || role === 'WAREHOUSE';

  async function run(fn, e) {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    try { await fn(f); e.target.reset(); setMsg(''); load(); } catch (x) { setMsg(x.message); }
  }
  const addWh = (e) => run((f) => api('/warehouses', 'POST', { name: f.name, lat: +f.lat, lng: +f.lng }), e);
  const addStock = (e) => run((f) => api(`/warehouses/${f.warehouseId}/stock`, 'POST',
    { type: f.type, quantity: +f.quantity, threshold: +f.threshold || 0 }), e);

  if (error) return <p className="error">{error}</p>;
  if (!list) return <p>Loading…</p>;
  const lowCount = list.flatMap((w) => w.stock).filter((s) => s.low).length;

  return (
    <section>
      <h2>Warehouses</h2>
      {lowCount > 0 && <p className="badge CRITICAL">{lowCount} stock lines are at or below their alert level</p>}
      {msg && <p className="error">{msg}</p>}
      {canEdit && (
        <div className="forms">
          <form className="card" onSubmit={addWh}>
            <h3>Register a warehouse</h3>
            <input name="name" placeholder="Warehouse name" required />
            <input name="lat" type="number" step="any" placeholder="Latitude" required />
            <input name="lng" type="number" step="any" placeholder="Longitude" required />
            <button>Add warehouse</button>
          </form>
          <form className="card" onSubmit={addStock}>
            <h3>Add stock</h3>
            <select name="warehouseId" required>{list.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}</select>
            <select name="type">{TYPES.map((t) => <option key={t}>{t}</option>)}</select>
            <input name="quantity" type="number" min="1" placeholder="Units to add" required />
            <input name="threshold" type="number" min="0" placeholder="Low-stock alert level (optional)" />
            <button>Add stock</button>
          </form>
        </div>
      )}
      <div className="grid">
        {list.map((w) => (
          <div className="card" key={w.id}>
            <h3>{w.name}</h3>
            {w.stock.length === 0 && <p>No stock registered.</p>}
            <table>
              <tbody>
                {w.stock.map((s) => (
                  <tr key={s.id}>
                    <td>{s.type}</td><td>{s.quantity}</td>
                    <td>{s.low && <span className="badge CRITICAL">low</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
      </div>
    </section>
  );
}
